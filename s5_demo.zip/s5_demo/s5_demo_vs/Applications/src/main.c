/*************************************************************************************************************
����:     ѭ�����nfc��,����⵽��,��������д����,�ɹ����ٶ���,ͨ�����ڷ���
�汾:     2023-5-16 V1.0
�޸ļ�¼: ��
����:     ZZZ
�����ʽ��GB2312
*************************************************************************************************************/

#include "gd32f4xx.h"
#include "gd32f470z_eval.h"
#include "main.h"
#include "i2c.h"
#include "stdio.h"
#include "string.h"
#include "s5.h"

uint16_t  delay_count = 0;                 //��ʱ����
uint16_t  time_count = 0;                  //1s��ʱ����

uint8_t   second_flag = 0;				   //ʱ���־

uint8_t   print_buffer[100];

i2c_addr_def s5_addr;					   //S5��ַ�ṹ��i2c_addr_def
i2c_addr_def e2_fan_addr;

uint8_t wd_buffer[20];					   //NFC�����ݻ���
uint8_t DefaultKey[6] = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};		//Ĭ������
uint8_t ucArray_ID[6];						

//ʶ���־
uint8_t back_stat = 0;
uint8_t stat = 0;
void setPWM(uint32_t i2c_periph, uint8_t i2c_addr, uint8_t num, uint16_t on, uint16_t off)
{ // Set signal PWM
    i2c_byte_write(i2c_periph, i2c_addr, LED0_ON_L + 4 * num, on);
    i2c_byte_write(i2c_periph, i2c_addr, LED0_ON_H + 4 * num, on >> 8);
    i2c_byte_write(i2c_periph, i2c_addr, LED0_OFF_L + 4 * num, off);
    i2c_byte_write(i2c_periph, i2c_addr, LED0_OFF_H + 4 * num, off >> 8);
}
void setPWM_off(uint32_t i2c_periph, uint8_t i2c_addr)
{ // turn off LED
    i2c_byte_write(i2c_periph, i2c_addr, ALLLED_ON_L, 0);
    i2c_byte_write(i2c_periph, i2c_addr, ALLLED_ON_H, 0);
    i2c_byte_write(i2c_periph, i2c_addr, ALLLED_OFF_L, 0);
    i2c_byte_write(i2c_periph, i2c_addr, ALLLED_OFF_H, 0);
}
void init_e2(void)
{
	uint8_t i;
	for (i = 0; i < 4; i++) // һ��һ����ַ����Ѱ�ң���Ӧ�ĸ���ַ���ɹ��ҵ������ṹ��
    {
        if (i2c_addr_poll(I2C0, PCA9685_ADDRESS_E2 + i * 2)) {
            e2_fan_addr.periph = I2C0; // periphָ������һ������i2c�豸
            e2_fan_addr.addr   = PCA9685_ADDRESS_E2 + i * 2;
            e2_fan_addr.flag   = 1;
            break;
        }
    }
    // address not read
    if (e2_fan_addr.flag != 1) // ��ʾû���ҵ���ͨ���豸,i2c0�����Ծͻ�i2c1
    {
        // poll I2C1,Verti1
        for (i = 0; i < 4; i++) {
            if (i2c_addr_poll(I2C1, PCA9685_ADDRESS_E2 + i * 2)) {
                e2_fan_addr.periph = I2C1;
                e2_fan_addr.addr   = PCA9685_ADDRESS_E1 + i * 2;
                e2_fan_addr.flag   = 1;
                break;
            }
        }
    }
    // read successful �ɹ�ͨ��
    if (e2_fan_addr.flag) {
        i2c_byte_write(e2_fan_addr.periph, e2_fan_addr.addr, PCA9685_MODE1, 0x0);
        setPWM_off(e2_fan_addr.periph, e2_fan_addr.addr);
    }
}
void pc9685_motor_control(uint32_t i2c_periph, uint8_t i2c_addr, uint8_t num)
{
    i2c_byte_write(i2c_periph, i2c_addr, PCA9685_MODE1, 0x0);
    switch (num) {
        // 关闭
        case 0:
            setPWM(i2c_periph, i2c_addr, 0x0, 0x0199, 0x1000);
            break;
        // 30%
        case 1:
            setPWM(i2c_periph, i2c_addr, 0x0, 0x0199, 0x0665);
            break;
        // 60%
        case 2:
            setPWM(i2c_periph, i2c_addr, 0x0, 0x0199, 0x0B32);
            break;
        // 90%
        case 3:
            setPWM(i2c_periph, i2c_addr, 0x0, 0x0199, 0x0FFF);
            break;
        // turn off
        default:
            setPWM(i2c_periph, i2c_addr, 0x0, 0x0199, 0x1000);
            break;
    }
}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////
int main(void)
{
	nvic_priority_group_set(NVIC_PRIGROUP_PRE4_SUB0);

	gd_eval_com_init(EVAL_COM0); 

	timer3_init(); 
	init_i2c();

	s5_addr = s5_init(MS523_ADDRESS_S5);
	init_e2();
	uint8_t cnt=0;
	while(1)
	{		
		if(second_flag)//ÿ300msִ��һ��
		{
			second_flag = 0;
			if(s5_addr.flag)
			{	 
				if(s5_detect(s5_addr.periph,s5_addr.addr,ucArray_ID)) 
				{
					if(s5_verify(s5_addr.periph,s5_addr.addr,PICC_AUTHENT1A,5,DefaultKey,ucArray_ID) == 0)
					{
						stat = 1;
						if(stat != back_stat)
						{	
							cnt++;
							if(cnt==1)
							{
								memset(wd_buffer,0,20);
								strncpy((char*)wd_buffer,"10100000000000\r\n",16);
								if(s5_write_data(s5_addr.periph,s5_addr.addr,6,wd_buffer) == 0)
								{	
									memset(wd_buffer,0,20);
									if(s5_read_data(s5_addr.periph,s5_addr.addr,6,wd_buffer) == 0)
									{
										if(wd_buffer[0]==0x31 && wd_buffer[1]==0x30 && wd_buffer[2]==0x31) pc9685_motor_control(e2_fan_addr.periph, e2_fan_addr.addr, 1);
										debug_printf(EVAL_COM0,(char *)wd_buffer);
									}
								}
							}
							else if (cnt==2)
							{
								memset(wd_buffer,0,20);
								strncpy((char*)wd_buffer,"11000000000000\r\n",16);
								if(s5_write_data(s5_addr.periph,s5_addr.addr,6,wd_buffer) == 0)
								{	
									memset(wd_buffer,0,20);
									if(s5_read_data(s5_addr.periph,s5_addr.addr,6,wd_buffer) == 0)
									{
										if(wd_buffer[0]==0x31 && wd_buffer[1]==0x31 && wd_buffer[2]==0x30) pc9685_motor_control(e2_fan_addr.periph, e2_fan_addr.addr, 2);
										debug_printf(EVAL_COM0,(char *)wd_buffer);
									}
			
								}
							}
							else if (cnt==3)
							{
								memset(wd_buffer,0,20);
								strncpy((char*)wd_buffer,"11100000000000\r\n",16);
								if(s5_write_data(s5_addr.periph,s5_addr.addr,6,wd_buffer) == 0)
								{	
									memset(wd_buffer,0,20);
									if(s5_read_data(s5_addr.periph,s5_addr.addr,6,wd_buffer) == 0)
									{
										if(wd_buffer[0]==0x31 && wd_buffer[1]==0x31 && wd_buffer[2]==0x31) pc9685_motor_control(e2_fan_addr.periph, e2_fan_addr.addr, 3);
										debug_printf(EVAL_COM0,(char *)wd_buffer);
									}
								
								}
							}
							else if(cnt==4)
							{
								memset(wd_buffer,0,20);
								strncpy((char*)wd_buffer,"00100000000000\r\n",16);
								if(s5_write_data(s5_addr.periph,s5_addr.addr,6,wd_buffer) == 0)
								{	
									memset(wd_buffer,0,20);
									if(s5_read_data(s5_addr.periph,s5_addr.addr,6,wd_buffer) == 0)
									{
										if(wd_buffer[0]==0x30 && wd_buffer[1]==0x30 && wd_buffer[2]==0x31) pc9685_motor_control(e2_fan_addr.periph, e2_fan_addr.addr, 0);
										debug_printf(EVAL_COM0,(char *)wd_buffer);
									}
								
								}
								cnt=0;
							}				
						}													
					}    									
				} 
				else
				{
					stat = 0;
				}	
				back_stat = stat;	
				s5_sleep(s5_addr.periph,s5_addr.addr);		
			}
			else
			{
				sprintf((char *)print_buffer,(const char*)"�Ҳ���S5�Ӱ�\r\n"); 
				debug_printf(EVAL_COM0,(char*)print_buffer);
			}								 
		}						
	}
}


	
/***********************************************************************************************************
//timer3 init 1ms��ʱ
************************************************************************************************************/
void timer3_init(void)
{
		timer_parameter_struct timer_init_struct;
		
		rcu_periph_clock_enable(RCU_TIMER3);
		
		timer_deinit(TIMER3);
		timer_init_struct.prescaler			= 4199;	
		timer_init_struct.period			= 20;
		timer_init_struct.alignedmode		= TIMER_COUNTER_EDGE;
		timer_init_struct.counterdirection	= TIMER_COUNTER_UP;		
		timer_init_struct.clockdivision		= TIMER_CKDIV_DIV1;		
		timer_init_struct.repetitioncounter = 0;				
		timer_init(TIMER3, &timer_init_struct);
		
		nvic_irq_enable(TIMER3_IRQn, 1, 1); 
		timer_interrupt_enable(TIMER3, TIMER_INT_UP);
		timer_enable(TIMER3);
}



/*********************************************************************************************************
������:     uart_print
��ڲ���:   usart_periph ���ں�USART0��USART2, *data Ҫ���͵�����,len Ҫ�������ݵĳ���
���ڲ���:   ��
����ֵ:     �ɹ��������ݳ��� ����������󷵻�-1
����:       yhh
����:       2023/7/10
��������:   ���ڷ�������,�ɹ����ط������ݳ���,����������󷵻�-1
**********************************************************************************************************/
int uart_print(uint32_t usart_periph, uint8_t *data, uint16_t len)
{
	uint8_t i;
	// ���USART�����Ƿ���Ч
	if (usart_periph != USART0 && usart_periph != USART2)
	{
		return -1;
	}

	// �������ָ���Ƿ�Ϊ��
	if (data == NULL)
	{
		return -1;
	}

	// ������ݳ����Ƿ����0
	if (len <= 0)
	{
		return -1;
	}

	for(i = 0; i < len; i++) 
	{
		while(usart_flag_get(usart_periph, USART_FLAG_TC) == RESET);      
		usart_data_transmit(usart_periph, data[i]);
	}
	while(usart_flag_get(usart_periph, USART_FLAG_TC) == RESET);
	return len;
}

/********************************************************************************************************
���Դ��ڷ�������
*********************************************************************************************************/
void debug_printf(uint32_t usart_periph,char *string)
{
	uint8_t  buffer[100];
	uint16_t len;

	len = strlen(string);
	strncpy((char*)buffer,string,len);
	uart_print(usart_periph,buffer,len);
}
/********************************************************************************************************
1ms��ʱ�жϷ������
*********************************************************************************************************/
void TIMER3_IRQHandler(void)
{
	if(timer_interrupt_flag_get(TIMER3, TIMER_INT_FLAG_UP))
	{
		   timer_interrupt_flag_clear(TIMER3, TIMER_INT_FLAG_UP);
		
		   if(delay_count > 0)
			 delay_count--;	 
		
		   if(time_count++ >= 300)
		   {
					time_count = 0;
					second_flag = 1;
		   }					 
	}
}







